using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public float speed;
    public Text countText;
	public Text winText;
	
	Rigidbody2D rb2d;
	
	int count;
    // Start is called before the first frame update
    void Start()
    {
	rb2d = GetComponent<Rigidbody2D>();
        winText.text = string.Empty;
		
		count = 0;
		SetCountText();
        
    }

    // Update is called once per frame
    void Update()
    {
      float moveHorizontal = Input.GetAxis("Horizontal");
      float moveVertical = Input.GetAxis("Vertical");  
      var movement = new Vector2(moveHorizontal, moveVertical);
      rb2d.AddForce(movement * speed);
    }
    void OnTriggerEnter2D(Collider2D target)
	{
		if (target.gameObject.CompareTag("Pickup")) 
		{
			target.gameObject.SetActive(false);
                        Destroy(target.gameObject);
			count += 1;
			SetCountText();
		}
	}

	void SetCountText()
	{
		countText.text = $"Count: {count}";
		if (count >= 11)
		{
			winText.text = "You win!";
		}
	}
}
